package com.example.fast.abot.activity;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;


import com.example.fast.abot.R;
import com.example.fast.abot.adapter.MessageAdapter;
import com.example.fast.abot.model.ResponseMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;



public class MainActivity extends AppCompatActivity {

    EditText userInput;
    RecyclerView recyclerView;
    MessageAdapter messageAdapter;
    List<ResponseMessage> responseMessageList;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar=(Toolbar) findViewById (R.id.appbar);
        setSupportActionBar (toolbar);
        userInput = findViewById(R.id.userInput);
        recyclerView = findViewById(R.id.conversation);
        responseMessageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(responseMessageList, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false));
        recyclerView.setAdapter(messageAdapter);

        userInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (i == EditorInfo.IME_ACTION_SEND) {
                    ResponseMessage responseMessage = new ResponseMessage(userInput.getText().toString(), true);
                    responseMessageList.add(responseMessage);

                    try {
                        JSONObject obj=new JSONObject();
                        obj.put("Sentence",userInput.getText().toString());
                        sendMsg(obj);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }
                return false;
            }
        });


    }
    boolean isLastVisible() {
        LinearLayoutManager layoutManager = ((LinearLayoutManager) recyclerView.getLayoutManager());
        int pos = layoutManager.findLastCompletelyVisibleItemPosition();
        int numItems = recyclerView.getAdapter().getItemCount();
        return (pos >= numItems);
    }


    private void sendMsg(final JSONObject obj)
    {
        final Handler handler=new Handler();
        Thread thread=new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Socket s=new Socket("192.168.18.6",6027);
                    OutputStream out=s.getOutputStream();
                    PrintWriter output=new PrintWriter(out);
                    output.println(obj.toString());
                    output.flush();
                    BufferedReader reader=new BufferedReader(new InputStreamReader(s.getInputStream()));
                    final String str=reader.readLine();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            JSONObject obj= null;
                            try {
                                obj = new JSONObject(str);
                                String lab=obj.getString("label");

                                ResponseMessage responseMessage2 = new ResponseMessage(lab, false);
                                responseMessageList.add(responseMessage2);

                                messageAdapter.notifyDataSetChanged();
                                if (!isLastVisible())
                                    recyclerView.smoothScrollToPosition(messageAdapter.getItemCount() - 1);



                                if(lab.equalsIgnoreCase("0"))
                                {


                                }
                                else if (lab.equalsIgnoreCase("1"))
                                {

                                }




                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    output.close();
                    out.close();
                    s.close();
                } catch (IOException e) {
                    System.out.println ("hello from three");
                    e.printStackTrace();
                }

            }
        });
        thread.start();
    }


}
